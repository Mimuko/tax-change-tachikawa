'use client'

import { useEffect, useState } from 'react'

const data = [
  { label: '高齢者人口', short: '高齢者', value: '+1%', color: 'sage', points: '0,188 130,184 260,180 390,176 520,172' },
  { label: '要支援・要介護認定者', short: '認定者', value: '+7%', color: 'orange', points: '0,188 130,178 260,165 390,148 520,126' },
  { label: '介護給付費', short: '給付費', value: '+12%', color: 'ink', points: '0,188 130,172 260,150 390,124 520,92' },
  { label: 'サービスの受け皿', short: '受け皿', value: '+4%', color: 'blue', points: '0,188 130,186 260,178 390,170 520,158' },
]

const details = ['介護を必要とする人', 'サービスの受け皿', '支える人', '待遇', '行政支出', '保険料', 'データの出典']

export default function Home() {
  const [visibleCount, setVisibleCount] = useState(1)
  const [detailOpen, setDetailOpen] = useState<string | null>(null)

  useEffect(() => {
    const onScroll = () => {
      const progress = Math.min(window.scrollY / 1300, 1)
      setVisibleCount(progress > 0.75 ? 4 : progress > 0.45 ? 3 : progress > 0.18 ? 2 : 1)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollToStory = () => document.getElementById('story')?.scrollIntoView({ behavior: 'smooth' })

  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="wordmark" href="#top" aria-label="税金で、何が変わった？ トップへ">TACHIKAWA / 介護の5年間</a>
        <div className="topbar-meta"><span>DATA STORY</span><span>2024.03</span></div>
      </header>

      <section id="top" className="hero">
        <div className="hero-kicker"><span className="dot" /> 立川市の変化をたどる</div>
        <h1>自分の街は、<br /><em>どう変わった？</em></h1>
        <p className="hero-lead">数字を覚えるためではなく、<br />変化に気づくための5年間です。</p>
        <div className="hero-bottom">
          <div><span className="label">対象</span><strong>立川市 / 介護 / 直近5年間</strong></div>
          <button onClick={scrollToStory} className="circle-button" aria-label="変化を見る">変化<br />を見る <span>↓</span></button>
        </div>
        <div className="hero-mark" aria-hidden="true">05<br /><span>YEARS</span></div>
      </section>

      <section id="story" className="story-section">
        <div className="section-intro"><span className="eyebrow">01 — まず、ひとつの変化</span><h2>高齢者の数は、<br />どう変わった？</h2><p>介護保険に加入する65歳以上の人を、2019年を100とした変化で見てみます。</p></div>
        <div className="sticky-visual">
          <div className="chart-head"><span>変化の速度を比べる</span><span>2019年を 100 とする</span></div>
          <div className="chart-area">
            <div className="grid-lines"><i /><i /><i /><i /><i /></div>
            <div className="y-labels"><span>115</span><span>110</span><span>105</span><span>100</span><span>95</span></div>
            <svg viewBox="0 0 520 220" role="img" aria-label="2019年を100とした5年間の変化を示す線グラフ">
              {data.slice(0, visibleCount).map((item) => <polyline key={item.label} className={`line ${item.color}`} points={item.points} fill="none" />)}
              {data.slice(0, visibleCount).map((item) => <circle key={`${item.label}-end`} className={`end-dot ${item.color}`} cx="520" cy={item.color === 'sage' ? 172 : item.color === 'orange' ? 126 : item.color === 'ink' ? 92 : 158} r="5" />)}
            </svg>
            <div className="x-labels"><span>2019</span><span>2020</span><span>2021</span><span>2022</span><span>2023</span></div>
          </div>
          <div className="legend" aria-live="polite">{data.slice(0, visibleCount).map((item) => <div key={item.label} className="legend-item"><span className={`legend-line ${item.color}`} /><span>{item.label}</span><strong>{item.value}</strong></div>)}</div>
          <div className="chart-note">※ 数値はストーリー体験のための仮値です。実データではありません。</div>
        </div>
      </section>

      <section className="pause-section"><span className="eyebrow">気づきのための間</span><h2>人の変化と、<br />お金の変化。</h2><p>では、それを支える側は？</p><div className="pause-arrow">↓</div></section>

      <section className="support-section">
        <div className="section-intro"><span className="eyebrow">02 — 支える側を重ねる</span><h2>変化のすべてを、<br /><em>一度に見る。</em></h2><p>需要に対して、サービスや働く人はどう変わったのか。同じ時間軸に重ねると、伸び方の違いが見えてきます。</p></div>
        <div className="comparison-board"><div className="board-title"><span>5年間の変化</span><small>それぞれの指標を指数化</small></div>{data.map((item, index) => <div className="board-row" key={item.label}><span className={`board-mark ${item.color}`} /> <span>{item.label}</span><div className="board-bar"><i className={item.color} style={{ width: `${index === 2 ? 88 : index === 1 ? 72 : index === 3 ? 48 : 20}%` }} /></div><strong>{item.value}</strong></div>)}<div className="reference-tag">待遇 — 東京都参考指標</div><div className="board-row"><span className="board-mark purple" /><span>介護職の待遇</span><div className="board-bar"><i className="purple" style={{ width: '34%' }} /></div><strong>+3%</strong></div></div>
      </section>

      <section className="detail-section"><span className="eyebrow">03 — もう少し詳しく</span><h2>具体的には、<br />何が起きている？</h2><p>気になったテーマから、具体値・定義・出典を確認できます。</p><div className="detail-list">{details.map((detail, index) => <button key={detail} className="detail-row" onClick={() => setDetailOpen(detailOpen === detail ? null : detail)} aria-expanded={detailOpen === detail}><span className="detail-num">0{index + 1}</span><span>{detail}</span><span className="detail-plus">{detailOpen === detail ? '−' : '+'}</span>{detailOpen === detail && <span className="detail-popover">ここに詳細データ、前年比、5年前比、内訳、定義、出典が入ります。</span>}</button>)}</div></section>

      <section className="closing-section"><div className="closing-number">04</div><h2>あなたは、<br /><em>何が気になりましたか？</em></h2><p>答えを決めるのは、このデータを見るあなたです。</p><button className="share-button">気づきを共有する <span>↗</span></button></section>

      <footer className="footer"><div><strong>税金で、何が変わった？</strong><p>立川市の介護をめぐるデータストーリー</p></div><div className="footer-links"><span>行政公開データを使用</span><span>非公式サイト</span><span>原典を見る ↗</span><span>GitHubで公開 ↗</span></div><small>Prototype / Data is illustrative</small></footer>
    </main>
  )
}
